'use strict';

var cacheVersion = 1;
var currentCache = {
  offline: 'offline-cache' + cacheVersion
};

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(currentCache.offline).then(function(cache) {
      return cache.addAll([
          '/offline.html'
      ]);
    })
  );
});

self.addEventListener('fetch', event => {
  // request.mode = navigate isn't supported in all browsers
  // so include a check for Accept: text/html header.
  if (event.request.mode === 'navigate' || (event.request.method === 'GET' && event.request.headers.get('accept').includes('text/html'))) {
        event.respondWith(
          fetch(event.request.url).catch(error => {
              // Return the offline page
              return caches.match('/offline.html');
          })
    );
  }
  else{
        // Respond with everything else if we can
        event.respondWith(caches.match(event.request)
                        .then(function (response) {
                        return response || fetch(event.request);
                    })
            );
      }
});

self.addEventListener('push', function(event) {
  //푸시 리스너
  var payload = event.data.json();
  const title = payload.title;
  const options = {
    body: payload.body,
    icon: 'images/fav.ico',
    badge: 'images/badge.png',
    vibrate: [200, 100, 200, 100, 200, 100, 400],
    data : payload.params
  };
  event.waitUntil( self.registration.showNotification(title, options) );
});
  
self.addEventListener('notificationclick', function(event) {
  //푸시 노티피케이션 에서 클릭 리스너
  var data = event.notification.data;
  event.notification.close();
  event.waitUntil( clients.openWindow( data.url ) );
});