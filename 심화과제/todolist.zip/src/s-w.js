self.addEventListener('install', function(event) { 
  var offlineRequest = new Request('offline.html');
event.waitUntil(
  fetch(offlineRequest).then(function(response) {
    return caches.open('offline').then(function(cache) {
      console.log('[oninstall] Cached offline page', response.url);
      return cache.put(offlineRequest, response);
    });
  })
);
});

self.addEventListener('fetch', function(event) {
  var request = event.request;
  if (request.method === 'GET') {
    event.respondWith(
      fetch(request).catch(function(error) {
        console.error(
          '[onfetch] Failed. Serving cached offline fallback ' +
          error
        );
        return caches.open('offline').then(function(cache) {
          return cache.match('offline.html');
        });
      })
    );
  }
});

self.addEventListener('push', function(event) {
	var payload = event.data.json();
	const title = payload.title;
	const options = {
		body: payload.body,
		icon: 'images/fav.ico',
		badge: 'images/badge.png',
		vibrate: [200, 100, 200, 100, 200, 100, 400],
		data : payload.params
	};
	event.waitUntil( self.registration.showNotification(title, options) );
});

self.addEventListener('notificationclick', function(event) {
	var data = event.notification.data;
	event.notification.close();
	event.waitUntil( clients.openWindow( data.url ) );
});