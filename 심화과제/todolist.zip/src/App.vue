<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
  import { authRef } from './store/db.js';
  import { mapGetters } from 'vuex';
  export default {  
    created(){
        authRef.onAuthStateChanged(user=>{
            if(!user) this.$router.push('/');
            else{
              this.$store.commit('userAuth',user);
            }
        })
    },
  } 
</script>
<style>
  body {
    text-align: center;
    background-color: #F6F6F8;
  }
  input {
    border-style: groove;
    width: 200px;
  }
  button {
    border-style: groove;
  }
  .shadow {
    box-shadow: 5px 10px 10px rgba(0, 0, 0, 0.03)
  }
</style>
