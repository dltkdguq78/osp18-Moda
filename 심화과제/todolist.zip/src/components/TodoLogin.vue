
<template>
    <section>
        <div>
            <img src="../assets/android-chrome-192x192.png">
            <h1>Moda</h1>
            <p>You need to sign in to use this service!</p>
            <input type="text" class="loginform" placeholder="  E-Mail"/>
            <input type="text" class="loginform" placeholder="  Password"/>
            <button class = "loginBtn" @click=eLogin>LOG IN</button>
            <button class = "loginBtn" @click="signModal=true">SIGN IN</button>
            <div class="sns-login">
                <button @click=gLogin>
                    <i class="google login fa fa-google"></i>
                </button>
                <button @click=tLogin>
                    <i class="twitter login fa fa-twitter"></i>
                </button>
            </div>
        </div>

        <modal v-if="signModal">
            <h3 slot="header">회원가입</h3>
            <span slot = "input">
            </span>       
            <span slot = "footer">   
                <i class="ModalBtn fas fa-check" aria-hidden="true"></i>
                <i class="ModalBtn fas fa-times" aria-hidden="true" @click ="signModal=false"></i>
            </span>
        </modal>
    </section>    
</template>

<script>
import Modal from './common/Modal.vue'
import { authRef } from '../store/db.js';

export default {
    data() {
		return {
            signModal: false,
		}
    },
    methods:{
        signin(){
            //곧넣을거심
        },
        gLogin(){
            this.$store.dispatch('userAuth',1);
        },
        tLogin(){
            this.$store.dispatch('userAuth',2);
        },
        eLogin(){
            this.$store.dispatch('userAuth',3);
        }
    },
    beforeCreate(){
        authRef.onAuthStateChanged(user=>{
            if(user) this.$router.push('todo');            
        });
    },      
    components: {
         Modal: Modal,
    }    
}

</script>
<style>
.login {
    margin-top: 20px;
    padding: 18px;
    font-size: 18px;
    width: 18px;
    text-align: center;
    text-decoration: none;
    border-radius: 50%;
}
.login:hover {
    opacity: 0.7;
}
.fa-google {
    background: white;
    color: #2196F3;
}
.fa-twitter {
    background: #55ACEE;
    color: white;
}
.loginBtn{
    background: linear-gradient(to bottom, #48c6ef, #6f86d6);
    font-size: 18px;
    border: none;
    color: white;
    padding: 12px 39px;
    cursor: pointer;
    border-radius: 4px;
}
button{
    background-color: rgba(0,0,0,0.0);
    border: none;
}
body {
    text-align: center;
    background-color: #F6F6F8;
}
img{
    width: 188px;
    height: 188px;
    margin-top: 3%;
    border-radius: 50%;
}
.loginform {
    display: block;
    width: 260px;
    height: 12px;
    margin : 6px auto;
    padding: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
}
</style>
