<template>
  <div>
    <h1> Hey, You need LOGIN!! </h1>
    <button @click=gLogin>Google Login</button>
  </div>
</template>
<script>

import { authRef } from '../store/db.js';
export default {
    methods:{
        gLogin(){
            this.$store.dispatch('userAuth');
        }
    },
    beforeCreate(){
        authRef.onAuthStateChanged(user=>{
            if(user) this.$router.push('todo');            
        });
    }    
}

</script>
<style>
  body {
    text-align: center;
    background-color: #F6F6F8;
  }  
  button {
    border-style: groove;
  }
</style>
