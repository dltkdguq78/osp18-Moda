
<template>
  <div>
    <h1>Hello!</h1>
    <p>
      How to Login!
    </p>
    <button @click=gLogin>
      <i class="google login fa fa-google"></i>
    </button>
    <button @click=gLogin>
      <i class="twitter login fa fa-twitter"></i>
    </button>
  </div>
</template>
<script>

import { authRef } from '../store/db.js';

export default {
    methods:{
        gLogin(){
            this.$store.dispatch('userAuth');
        }
    },
    beforeCreate(){
        authRef.onAuthStateChanged(user=>{
            if(user) this.$router.push('todo');            
        });
    }    
}

</script>
<style>
.login {
    padding: 20px;
    font-size: 30px;
    width: 30px;
    text-align: center;
    text-decoration: none;
    border-radius: 50%;
}
.login:hover {
    opacity: 0.7;
}

/* Set a specific color for each brand */

/* Facebook */
.fa-google {
    background: white;
    color: #2196F3;
}
button{
    background-color: rgba(0,0,0,0.0);
    border: none;
}
.fa-twitter {
    background: #55ACEE;
    color: white;
}
  body {
    text-align: center;
    background-color: #F6F6F8;
  }  
</style>
