
<template>
  <div>
    <img src="../assets/android-chrome-192x192.png">
    <h1>Moda</h1>
    <p>You need to sign in to use this service!</p>
    <input type="text" placeholder="  E-Mail"/>
    <input type="text" placeholder="  Password"/>
    <div class="sns-login">
        <button @click=gLogin>
        <i class="google login fa fa-google"></i>
        </button>
        <button @click=gLogin>
        <i class="twitter login fa fa-twitter"></i>
        </button>
    </div>
  </div>
</template>
<script>

import { authRef } from '../store/db.js';

export default {
    methods:{
        gLogin(){
            this.$store.dispatch('userAuth');
        }
    },
    beforeCreate(){
        authRef.onAuthStateChanged(user=>{
            if(user) this.$router.push('todo');            
        });
    }    
}

</script>
<style>
.login {
    padding: 20px;
    font-size: 20px;
    width: 20px;
    text-align: center;
    text-decoration: none;
    border-radius: 50%;
}
.login:hover {
    opacity: 0.7;
}

/* Set a specific color for each brand */

/* Facebook */
.fa-google {
    background: white;
    color: #2196F3;
}
button{
    margin-top: 20px;
    background-color: rgba(0,0,0,0.0);
    border: none;
}
.fa-twitter {
    background: #55ACEE;
    color: white;
}
body {
    text-align: center;
    background-color: #F6F6F8;
}
img{
    width: 188px;
    height: 188px;
    margin-top: 3%;
    border-radius: 50%;
}
input[type=text]{
    display: block;
    width: 300px;
    height: 30px;
    margin : 0 auto;
}
</style>
