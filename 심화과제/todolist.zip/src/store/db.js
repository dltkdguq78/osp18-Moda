import firebase from 'firebase/app';
import 'firebase/firestore';
import 'firebase/auth';

  var config = {
    apiKey: "AIzaSyCejxDdPwHrDVvu2WCFQJ_dCI4tRuH7mTg",
    authDomain: "osp18-moda2-2718a.firebaseapp.com",
    databaseURL: "https://osp18-moda2-2718a.firebaseio.com",
    projectId: "osp18-moda2-2718a",
    storageBucket: "osp18-moda2-2718a.appspot.com",
    messagingSenderId: "749403926489"
  };
  firebase.initializeApp(config);

const db = firebase.firestore();
db.settings({
    timestampsInSnapshots: true
});
const dbRef = db.collection('user');
const authRef = firebase.auth();
authRef.setPersistence(firebase.auth.Auth.Persistence.SESSION);


const gProvider = new firebase.auth.GoogleAuthProvider();
const tProvider = new firebase.auth.TwitterAuthProvider();
export {authRef, dbRef, gProvider, tProvider};

