import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex); // vuex 사용

export const store = new Vuex.Store({ // store export
    state:{
        todoItems:[],
        search:'',
        viewType : false
    },
    getters:{
        getTodos: state => {
            return state.todoItems;
        },
        getSearch: state => {
            return state.search;
        },
        getType: state => {
            return state.viewType;
        }
    },
    mutations:{
        addTodo: (state, value) => {
            state.todoItems.push(value);
        },
        viewTodo: (state, value) =>{
            state.viewType = value;
        },  
        removeTodo: (state, index) => {
            state.todoItems.splice(index, 1);
        },
        clearAll: state =>{
            state.todoItems = [];
        },
        searchTodo: (state, value) =>{
            state.search = value;
        },        
        sortTodo: (state, value) =>{
            state.todoItems.sort(function(a,b){return a[value]>b[value]});

            state.todoItems.sort(function(a,b){return a['isComplete']>b['isComplete']});
        },
        isCompleteTodo: (state, index) =>{
            state.todoItems[index].isComplete = !state.todoItems[index].isComplete;
        }
    },
    actions:{
        clearAll: (context, time) => { // 비동기 작업 수행 후 mutation commit
            setTimeout(()=>context.commit('clearAll'),time)
        }
    }
});
